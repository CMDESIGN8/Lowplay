export const getEvents = () => {
    return [
      { id: 1, name: 'Evento 1', date: '2025-01-01' },
      { id: 2, name: 'Evento 2', date: '2025-01-02' },
    ];
  };