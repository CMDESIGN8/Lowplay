export const getTasks = () => {
    return [
      { id: 1, name: 'Tarea 1', completed: false },
      { id: 2, name: 'Tarea 2', completed: true },
    ];
  };